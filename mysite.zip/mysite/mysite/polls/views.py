from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render


import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objs as go
import plotly.tools as tls
from plotly.subplots import make_subplots

path1 = "valeursfoncieres-2023.txt"
vf = pd.read_csv(path1, sep='|')
vf["Valeur fonciere"] = vf["Valeur fonciere"].str.replace(',', '.').astype(float)

vf_clean = vf.drop(["Identifiant de document",'Reference document', '1 Articles CGI',
       '2 Articles CGI', '3 Articles CGI', '4 Articles CGI', '5 Articles CGI', 'Prefixe de section', 'No Volume' ,'1er lot','Surface Carrez du 1er lot', '2eme lot', 'Surface Carrez du 2eme lot',
       '3eme lot', 'Surface Carrez du 3eme lot', '4eme lot',
       'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot','Identifiant local','Nature culture speciale'], axis=1)


path2022 = "valeursfoncieres-2022.txt"
vf_2022 = pd.read_csv(path2022, sep='|')

vf_2022["Valeur fonciere"] = vf_2022["Valeur fonciere"].str.replace(',', '.').astype(float)

vf_clean_2022 = vf_2022.drop(["Identifiant de document",'Reference document', '1 Articles CGI',
       '2 Articles CGI', '3 Articles CGI', '4 Articles CGI', '5 Articles CGI', 'Prefixe de section', 'No Volume' ,'1er lot','Surface Carrez du 1er lot', '2eme lot', 'Surface Carrez du 2eme lot',
       '3eme lot', 'Surface Carrez du 3eme lot', '4eme lot',
       'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot','Identifiant local','Nature culture speciale'], axis=1)


vf_clean_2022['Code commune'] = vf_clean_2022['Code commune'].fillna(0)

vf_2022["Code commune"] = vf_2022["Code commune"].astype(int)



path2019 = "valeursfoncieres-2019.txt"
vf_2019 = pd.read_csv(path2019, sep='|')

vf_2019["Valeur fonciere"] = vf_2019["Valeur fonciere"].str.replace(',', '.').astype(float)

vf_clean_2019 = vf_2019.drop(["Identifiant de document",'Reference document', '1 Articles CGI',
       '2 Articles CGI', '3 Articles CGI', '4 Articles CGI', '5 Articles CGI', 'Prefixe de section', 'No Volume' ,'1er lot','Surface Carrez du 1er lot', '2eme lot', 'Surface Carrez du 2eme lot',
       '3eme lot', 'Surface Carrez du 3eme lot', '4eme lot',
       'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot','Identifiant local','Nature culture speciale'], axis=1)


vf_clean_2019['Code commune'] = vf_clean_2019['Code commune'].fillna(0)

vf_2019["Code commune"] = vf_2019["Code commune"].astype(int)


def index(request):
    #path1 = "valeursfoncieres-2023.txt"
    #vf = pd.read_csv(path1, sep='|')
    #vf["Valeur fonciere"] = vf["Valeur fonciere"].str.replace(',', '.').astype(float)

    #vf_clean = vf.drop(["Identifiant de document",'Reference document', '1 Articles CGI',
       #'2 Articles CGI', '3 Articles CGI', '4 Articles CGI', '5 Articles CGI', 'Prefixe de section', 'No Volume' ,'1er lot','Surface Carrez du 1er lot', '2eme lot', 'Surface Carrez du 2eme lot',
       #'3eme lot', 'Surface Carrez du 3eme lot', '4eme lot',
       #'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot','Identifiant local','Nature culture speciale'], axis=1)

    #template = loader.get_template("template0.html")
    

    # Filtrer les données pour Paris (codes postaux commençant par 75)
    df_paris = vf_clean[vf_clean['Code postal'].between(75001, 75999)]

    # Extraire le code d'arrondissement (les deux derniers chiffres du code postal)
    df_paris['Arrondissement'] = df_paris['Code postal'].apply(lambda x: '751' + str(int(x) - 75000).zfill(2))

    # Calculer la somme des valeurs foncières par arrondissement
    sum_valeurs_foncieres_paris = df_paris.groupby('Arrondissement')['Valeur fonciere'].sum().reset_index()

    # URL du fichier GeoJSON pour les arrondissements de Paris
    geojson_url = 'https://france-geojson.gregoiredavid.fr/repo/departements/75-paris/communes-75-paris.geojson'

    # Créer la carte choroplèthe
    fig = px.choropleth(sum_valeurs_foncieres_paris,
                        geojson=geojson_url,
                        locations='Arrondissement', # Colonne des arrondissements dans DataFrame
                        featureidkey="properties.code", # Chemin vers le code d'arrondissement dans le GeoJSON
                        color='Valeur fonciere',
                        color_continuous_scale="matter",
                        projection="mercator",
                        title='Somme des Valeurs Foncières par Arrondissement à Paris')

    # Afficher la carte
    fig.update_geos(fitbounds="locations", visible=False)

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    context = {
        "plot_html" : plot_html,
    }
    return render(request, "template0.html", context)

def index1(request):

    #template = loader.get_template("template0.html")
    

   # Calculer la somme des valeurs foncières par département
    sum_valeurs_foncieres = vf_clean.groupby('Code departement')['Valeur fonciere'].sum().reset_index()

    # Déterminer les valeurs minimale et maximale pour l'échelle de couleur
    min_value = sum_valeurs_foncieres['Valeur fonciere'].min()
    max_value = sum_valeurs_foncieres['Valeur fonciere'].max()

    # Préparer les données de géolocalisation pour les departements français
    # Utilisation d'un fichier GeoJSON pour les départements francais
    geojson_url = 'https://france-geojson.gregoiredavid.fr/repo/departements.geojson'

    # Créer la carte choroplèthe
    fig = px.choropleth(sum_valeurs_foncieres,
                        geojson=geojson_url,
                        locations='Code departement', # Nom de la colonne dans DataFrame
                        featureidkey="properties.code", # Chemin vers le code de département dans le GeoJSON
                        color='Valeur fonciere', # Colonne qui définit la couleur
                        color_continuous_scale="matter", # Échelle de couleur
                        range_color=(min_value, max_value), # Définition de l'échelle de couleur
                        projection="mercator",
                        title='Somme des valeurs foncières par département en France')

    # Afficher la carte
    fig.update_geos(fitbounds="locations", visible=False)

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    context = {
        "plot_html" : plot_html,
    }
    return render(request, "template1.html", context)


def surfaces_reelles_baties_2023():
    df_filtered = vf_clean[(~vf_clean['Surface reelle bati'].isnull()) & (vf_clean['Surface reelle bati'] != 0)]

    total_surfaces_baties_par_departement = df_filtered.groupby('Code departement')['Surface reelle bati'].sum()

    #total_surfaces_baties_par_departement.plot(kind='bar', figsize=(18, 9), color='purple')

    fig = px.bar(total_surfaces_baties_par_departement, 
             x=total_surfaces_baties_par_departement.index, 
             y=total_surfaces_baties_par_departement.values, 
             title="Total des Surfaces Bâties par Département 2023")

    # Limiter l'axe des abscisses à 100
    fig.update_layout(xaxis=dict(range=[0, 100]))


    #plt.xlabel('Département')
    #plt.ylabel('Total des surfaces réelles bâties')
    #plt.title('Total des surfaces réelles bâties par département 2023')

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def surfaces_reelles_baties_2022():
    df_filtered_2022 = vf_clean_2022[(~vf_clean_2022['Surface reelle bati'].isnull()) & (vf_clean_2022['Surface reelle bati'] != 0)]

    total_surfaces_baties_par_departement_2022 = df_filtered_2022.groupby('Code departement')['Surface reelle bati'].sum()

    fig = px.bar(total_surfaces_baties_par_departement_2022, 
             x=total_surfaces_baties_par_departement_2022.index, 
             y=total_surfaces_baties_par_departement_2022.values, 
             title="Total des Surfaces Bâties par Département 2022")

    fig.update_layout(xaxis=dict(range=[0, 100]))

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def surfaces_reelles_baties_2019():
    df_filtered_2019 = vf_clean_2019[(~vf_clean_2019['Surface reelle bati'].isnull()) & (vf_clean_2019['Surface reelle bati'] != 0)]

    total_surfaces_baties_par_departement = df_filtered_2019.groupby('Code departement')['Surface reelle bati'].sum()

    
    fig = px.bar(total_surfaces_baties_par_departement, 
             x=total_surfaces_baties_par_departement.index, 
             y=total_surfaces_baties_par_departement.values, 
             title="Total des Surfaces Bâties par Département 2019")

    fig.update_layout(xaxis=dict(range=[0, 100]))
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def totale_surface_dispo_construction():
    df_ab = vf[vf['Nature culture'] == 'AB']

    somme_surfaces_terrain_par_departement = df_ab.groupby('Code departement')['Surface terrain'].sum()

    fig = px.bar(somme_surfaces_terrain_par_departement, 
             x=somme_surfaces_terrain_par_departement.index, 
             y=somme_surfaces_terrain_par_departement.values, 
             title="Total des surfaces disponibles à la construction par département",
             color_discrete_sequence=['orange'])

    fig.update_layout(xaxis=dict(range=[0, 100]))

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def somme_vf_dep():
    somme_valeurs_foncieres_par_departement = vf_clean.groupby(vf_clean['Code departement'])['Valeur fonciere'].sum()

    fig = px.bar(somme_valeurs_foncieres_par_departement, 
             x=somme_valeurs_foncieres_par_departement.index, 
             y=somme_valeurs_foncieres_par_departement.values, 
             title="Somme des valeurs foncières par département",
             color_discrete_sequence=['green'])

    fig.update_layout(xaxis=dict(range=[0, 100]))

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def moyenne_des_valeurs_foncieres_par_departement():
    moyennes_valeurs_foncieres_par_departement = vf.groupby('Code departement')['Valeur fonciere'].mean()

    fig = px.bar(moyennes_valeurs_foncieres_par_departement, 
             x=moyennes_valeurs_foncieres_par_departement.index, 
             y=moyennes_valeurs_foncieres_par_departement.values, 
             title="Moyenne des valeurs foncières par département",
             color_discrete_sequence=['blue'])

    fig.update_layout(xaxis=dict(range=[0, 100]))

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def Paris():
    
    #template = loader.get_template("template0.html")
    

    # Filtrer les données pour Paris (codes postaux commençant par 75)
    df_paris = vf_clean[vf_clean['Code postal'].between(75001, 75999)]

    # Extraire le code d'arrondissement (les deux derniers chiffres du code postal)
    df_paris['Arrondissement'] = df_paris['Code postal'].apply(lambda x: '751' + str(int(x) - 75000).zfill(2))

    # Calculer la somme des valeurs foncières par arrondissement
    sum_valeurs_foncieres_paris = df_paris.groupby('Arrondissement')['Valeur fonciere'].sum().reset_index()

    # URL du fichier GeoJSON pour les arrondissements de Paris
    geojson_url = 'https://france-geojson.gregoiredavid.fr/repo/departements/75-paris/communes-75-paris.geojson'

    # Créer la carte choroplèthe
    fig = px.choropleth(sum_valeurs_foncieres_paris,
                        geojson=geojson_url,
                        locations='Arrondissement', # Colonne des arrondissements dans DataFrame
                        featureidkey="properties.code", # Chemin vers le code d'arrondissement dans le GeoJSON
                        color='Valeur fonciere',
                        color_continuous_scale="matter",
                        projection="mercator",
                        title='Somme des Valeurs Foncières par Arrondissement à Paris')

    # Afficher la carte
    fig.update_geos(fitbounds="locations", visible=False)

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html





def France():
    

    #template = loader.get_template("template0.html")
    

   # Calculer la somme des valeurs foncières par département
    sum_valeurs_foncieres = vf_clean.groupby('Code departement')['Valeur fonciere'].sum().reset_index()

    # Déterminer les valeurs minimale et maximale pour l'échelle de couleur
    min_value = sum_valeurs_foncieres['Valeur fonciere'].min()
    max_value = sum_valeurs_foncieres['Valeur fonciere'].max()

    # Préparer les données de géolocalisation pour les departements français
    # Utilisation d'un fichier GeoJSON pour les départements francais
    geojson_url = 'https://france-geojson.gregoiredavid.fr/repo/departements.geojson'

    # Créer la carte choroplèthe
    fig = px.choropleth(sum_valeurs_foncieres,
                        geojson=geojson_url,
                        locations='Code departement', # Nom de la colonne dans DataFrame
                        featureidkey="properties.code", # Chemin vers le code de département dans le GeoJSON
                        color='Valeur fonciere', # Colonne qui définit la couleur
                        color_continuous_scale="matter", # Échelle de couleur
                        range_color=(min_value, max_value), # Définition de l'échelle de couleur
                        projection="mercator",
                        title='Somme des valeurs foncières par département en France')

    # Afficher la carte
    fig.update_geos(fitbounds="locations", visible=False)

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def nombre_de_transactions_par_mois_par_departement_2023():
    vf['Date mutation'] = pd.to_datetime(vf['Date mutation'], errors='coerce')
    vf['Mois'] = vf['Date mutation'].dt.month
    transactions_par_mois_par_departement = vf.groupby(['Code departement', 'Mois']).size().unstack()

    data_for_plotly = transactions_par_mois_par_departement.reset_index().melt(id_vars=['Code departement'], var_name='Mois', value_name='Nombre de transactions')

    fig = px.bar(data_for_plotly, x='Code departement', y='Nombre de transactions', color='Mois',
                title='Nombre de transactions par mois par département', barmode='stack')

    fig.update_layout(xaxis=dict(range=[0, 100]),xaxis_title='Département', yaxis_title='Nombre de transactions')

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def nombre_transac_trim():
    vf['Date mutation'] = pd.to_datetime(vf['Date mutation'], errors='coerce')
    vf['Trimestre'] = vf['Date mutation'].dt.to_period('Q')
    transactions_par_trimestre_par_departement = vf.groupby(['Code departement', 'Trimestre']).size().unstack()

    # Transformation des données pour Plotly
    data_for_plotly = transactions_par_trimestre_par_departement.reset_index().melt(id_vars=['Code departement'], var_name='Trimestre', value_name='Nombre de transactions')

    # Conversion des périodes en chaînes pour l'affichage
    data_for_plotly['Trimestre'] = data_for_plotly['Trimestre'].astype(str)

    # Création du graphique avec Plotly Express
    fig = px.bar(data_for_plotly, x='Code departement', y='Nombre de transactions', color='Trimestre',
                title='Nombre de transactions par trimestre par département', barmode='stack')

    # Personnalisation des axes
    fig.update_layout(xaxis=dict(range=[0, 100]),xaxis_title='Département', yaxis_title='Nombre de transactions')

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html



def Nombre_de_Transactions_Immobilieres_par_mois_2023():
    vf_clean['Date mutation'] = pd.to_datetime(vf_clean['Date mutation'], format='%d/%m/%Y')
    vf_clean['Mois'] = vf_clean['Date mutation'].dt.month
    transactions_par_mois = vf_clean.groupby('Mois').size()

    # Préparation des couleurs conditionnelles
    couleurs = ['green' if x > 150000 else 'red' for x in transactions_par_mois]

    # Préparation des données pour Plotly
    data_for_plotly = transactions_par_mois.reset_index()
    data_for_plotly.columns = ['Mois', 'Nombre de Transactions']

    # Création du graphique avec Plotly Express
    fig = px.bar(data_for_plotly, x='Mois', y='Nombre de Transactions',
                title='Nombre de Transactions Immobilières par mois en 2023')

    # Appliquer les couleurs conditionnelles
    fig.update_traces(marker_color=couleurs)

    # Personnalisation des axes
    fig.update_layout(xaxis_title='Mois', yaxis_title='Nombre de Transactions')

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def Nombre_de_Transactions_Immobilieres_par_mois_2022():
    vf_clean_2022['Date mutation'] = pd.to_datetime(vf_clean_2022['Date mutation'], format='%d/%m/%Y')

    vf_clean_2022['Mois'] = vf_clean_2022['Date mutation'].dt.month

    transactions_par_mois_2022 = vf_clean_2022.groupby('Mois').size().reset_index(name='Nombre de Transactions')

    couleurs_2022 = ['green' if x > 400000 else 'red' for x in transactions_par_mois_2022['Nombre de Transactions']]

    fig = go.Figure()

    fig.add_trace(go.Bar(
        x=transactions_par_mois_2022['Mois'],
        y=transactions_par_mois_2022['Nombre de Transactions'],
        marker_color=couleurs_2022
    ))

    fig.update_layout(
        title='Nombre de Transactions Immobilières par mois en 2022',
        xaxis_title='Mois',
        yaxis_title='Nombre de Transactions'
    )

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def Nombre_de_Transactions_Immobilieres_par_mois_2019():
    vf_clean_2019['Date mutation'] = pd.to_datetime(vf_clean_2019['Date mutation'], format='%d/%m/%Y')
    vf_clean_2019['Mois'] = vf_clean_2019['Date mutation'].dt.month
    transactions_par_mois_2019 = vf_clean_2019.groupby('Mois').size()

    couleurs_2019 = ['green' if x > 300000 else 'red' for x in transactions_par_mois_2019]

    data_for_plotly_2019 = transactions_par_mois_2019.reset_index()
    data_for_plotly_2019.columns = ['Mois', 'Nombre de Transactions']

    fig = px.bar(data_for_plotly_2019, x='Mois', y='Nombre de Transactions',
                    title='Nombre de Transactions Immobilières par mois en 2019')

    fig.update_traces(marker_color=couleurs_2019)

    fig.update_layout(xaxis_title='Mois', yaxis_title='Nombre de Transactions')

    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

    

def Repartition_des_valeurs_foncieres_par_type_de_local_2023():
    vf_clean['valeur fonciere'] = vf_clean['Valeur fonciere'].fillna(0)
    grouped_vf = vf_clean.groupby('Type local')['Valeur fonciere'].sum()

    grouped_vf_percent = grouped_vf / grouped_vf.sum() * 100

    small_groups = grouped_vf_percent[grouped_vf_percent < 1]
    grouped_vf = grouped_vf.drop(small_groups.index)

    if small_groups.sum() > 0:
        grouped_vf['Autres'] = small_groups.sum()

    fig = px.pie(grouped_vf, names=grouped_vf.index, values=grouped_vf.values,
                labels={'Valeur fonciere': 'Valeur foncière'},
                title='Répartition des valeurs foncières par type de local en 2023',
                hover_data=['Valeur fonciere'],
                template='plotly_dark')

    fig.update_traces(textposition='inside', textinfo='percent+label')
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def Repartition_des_valeurs_foncieres_par_type_de_local_2022():
    vf_clean_2022['Valeur fonciere'] = vf_clean_2022['Valeur fonciere'].fillna(0)
    grouped_vf_2022 = vf_clean_2022.groupby('Type local')['Valeur fonciere'].sum()

    grouped_vf_percent_2022 = grouped_vf_2022 / grouped_vf_2022.sum() * 100

    small_groups_2022 = grouped_vf_percent_2022[grouped_vf_percent_2022 < 1]
    grouped_vf_2022 = grouped_vf_2022.drop(small_groups_2022.index)

    if small_groups_2022.sum() > 0:
        grouped_vf_2022['Autres'] = small_groups_2022.sum()

    data_for_plotly = grouped_vf_2022.reset_index()
    data_for_plotly.columns = ['Type local', 'Valeur fonciere']

    fig = px.pie(data_for_plotly, names='Type local', values='Valeur fonciere',
                title='Répartition des valeurs foncières par type de local en 2022',
                hover_data=['Valeur fonciere'],
                labels={'Valeur fonciere':'Valeur Foncière'})
    
    fig.update_traces(textposition='inside', textinfo='percent+label')
    
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def Repartition_des_valeurs_foncieres_par_type_de_local_2019():
    vf_clean_2019['Valeur fonciere'] = vf_clean_2019['Valeur fonciere'].fillna(0)
    grouped_vf_2019 = vf_clean_2019.groupby('Type local')['Valeur fonciere'].sum()

    # Calculer le pourcentage
    grouped_vf_percent_2019 = grouped_vf_2019 / grouped_vf_2019.sum() * 100

    # Filtrer les petits groupes
    small_groups_2019 = grouped_vf_2019[grouped_vf_percent_2019 < 1]
    grouped_vf_2019 = grouped_vf_2019.drop(small_groups_2019.index)

    # Ajouter un groupe 'Autres' si nécessaire
    if small_groups_2019.sum() > 0:
        grouped_vf_2019['Autres'] = small_groups_2019.sum()

    # Préparation des données pour Plotly
    data_for_plotly_2019 = grouped_vf_2019.reset_index()
    data_for_plotly_2019.columns = ['Type local', 'Valeur fonciere']

    # Création du graphique en camembert avec Plotly Express
    fig = px.pie(data_for_plotly_2019, names='Type local', values='Valeur fonciere',
                    title='Répartition des valeurs foncières par type de local en 2019',
                    hover_data=['Valeur fonciere'],
                    labels={'Valeur fonciere':'Valeur Foncière'})

    fig.update_traces(textposition='inside', textinfo='percent+label')
    
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def repatition_types_locaux_2023():
    type_local_counts = vf_clean['Type local'].value_counts()

    data_for_plotly = type_local_counts.reset_index()
    data_for_plotly.columns = ['Type local', 'Comptage']

    fig = px.pie(data_for_plotly, names='Type local', values='Comptage',
                title='Répartition des Types de Locaux',
                hover_data=['Comptage'],
                labels={'Comptage':'Nombre'})

    fig.update_traces(textinfo='percent+label')
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def repatition_types_locaux_2022():
    type_local_counts_2022 = vf_clean_2022['Type local'].value_counts()

    fig = px.pie(type_local_counts_2022, 
                names=type_local_counts_2022.index, 
                values=type_local_counts_2022.values, 
                title='Répartition des Types de Locaux en 2022')

    fig.update_traces(textinfo='percent+label')
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html

def repatition_types_locaux_2019():
    type_local_counts_2019 = vf_clean_2019['Type local'].value_counts()

    fig = px.pie(type_local_counts_2019, 
                names=type_local_counts_2019.index, 
                values=type_local_counts_2019.values, 
                title='Répartition des Types de Locaux en 2019')

    # Personnalisation du graphique pour 2019
    fig.update_traces(textinfo='percent+label')
    plot_html = fig.to_html(full_html=False, default_height=500, default_width=700)

    return plot_html


def index2(request):
    template = loader.get_template("template1.html")

    if(request.GET['model'] == "France"):
        plot_html1 = France()

    if(request.GET['model'] == "Paris"):
        plot_html1 = Paris()

    context = {
        "plot_html1" : plot_html1,
    }
    return HttpResponse(template.render(context, request))


def index3(request):
    template = loader.get_template("template1.html")

    if(request.GET['surface_reelles_baties'] == "2023"):
        plot_html2 = surfaces_reelles_baties_2023()

    if(request.GET['surface_reelles_baties'] == "2022"):
        plot_html2 = surfaces_reelles_baties_2022()
        
    if(request.GET['surface_reelles_baties'] == "2019"):
        plot_html2 = surfaces_reelles_baties_2019()


    context = {
        "plot_html2" : plot_html2,
    }
    return HttpResponse(template.render(context, request))


def index4(request):
    template = loader.get_template("template1.html")

    if(request.GET['surfaces-dispo-constru'] == "2023"):
        plot_html3 = totale_surface_dispo_construction()


    context = {
        "plot_html3" : plot_html3,
    }
    return HttpResponse(template.render(context, request))


def index5(request):
    template = loader.get_template("template1.html")

    if(request.GET['somme-vf-departement'] == "2023"):
        plot_html4 = somme_vf_dep()


    context = {
        "plot_html4" : plot_html4,
    }
    return HttpResponse(template.render(context, request))


def index6(request):
    template = loader.get_template("template1.html")

    if(request.GET['Moyenne_des_valeurs_foncieres_par_departement'] == "2023"):
        plot_html5 = moyenne_des_valeurs_foncieres_par_departement()

    context = {
        "plot_html5" : plot_html5,
    }
    return HttpResponse(template.render(context, request))


def index8(request):
    template = loader.get_template("template1.html")

    if(request.GET['Nombre_de_transactions_par_departement'] == "Mois"):
        plot_html7 = nombre_de_transactions_par_mois_par_departement_2023()
    
    if(request.GET['Nombre_de_transactions_par_departement'] == "Trimestre"):
        plot_html7 = nombre_transac_trim()



    context = {
        "plot_html7" : plot_html7,
    }
    return HttpResponse(template.render(context, request))


def index10(request):
    template = loader.get_template("template1.html")

    if(request.GET['Nombre_de_Transactions_Immobilieres_par_mois'] == "2023"):
        plot_html9 = Nombre_de_Transactions_Immobilieres_par_mois_2023()

    if(request.GET['Nombre_de_Transactions_Immobilieres_par_mois'] == "2022"):
        plot_html9 = Nombre_de_Transactions_Immobilieres_par_mois_2022()
        
    if(request.GET['Nombre_de_Transactions_Immobilieres_par_mois'] == "2019"):
        plot_html9 = Nombre_de_Transactions_Immobilieres_par_mois_2019()

    context = {
        "plot_html9" : plot_html9,
    }
    return HttpResponse(template.render(context, request))



def index11(request):
    template = loader.get_template("template1.html")

    if(request.GET['Repartition_des_valeurs_foncieres_par_type_de_local'] == "2023"):
        plot_html10 = Repartition_des_valeurs_foncieres_par_type_de_local_2023()

    if(request.GET['Repartition_des_valeurs_foncieres_par_type_de_local'] == "2022"):
        plot_html10 = Repartition_des_valeurs_foncieres_par_type_de_local_2022()
        
    if(request.GET['Repartition_des_valeurs_foncieres_par_type_de_local'] == "2019"):
        plot_html10 = Repartition_des_valeurs_foncieres_par_type_de_local_2019()



    context = {
        "plot_html10" : plot_html10,
    }
    return HttpResponse(template.render(context, request))


def index13(request):
    template = loader.get_template("template1.html")

    if(request.GET['repartition_des_types-de-locaux'] == "2023"):
        plot_html12= repatition_types_locaux_2023()
        
    if(request.GET['repartition_des_types-de-locaux'] == "2022"):
        plot_html12= repatition_types_locaux_2022()
       
    if(request.GET['repartition_des_types-de-locaux'] == "2019"):
        plot_html12= repatition_types_locaux_2019()

    context = {
        "plot_html12" : plot_html12,
    }
    return HttpResponse(template.render(context, request))

