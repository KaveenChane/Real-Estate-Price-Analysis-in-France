from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("page1", views.index1, name="index1"),
    path("apply_Model", views.index2, name="apply_Model"),
    path("apply_Model2", views.index3, name="apply_Model2"),
    path("apply_Model3", views.index4, name="apply_Model3"),
    path("apply_Model4", views.index5, name="apply_Model4"),
    path("apply_Model5", views.index6, name="apply_Model5"),
    path("apply_Model6", views.index8, name="apply_Model6"),
    path("apply_Model10", views.index10, name="apply_Model10"),
    path("apply_Model11", views.index11, name="apply_Model11"),
    path("apply_Model12", views.index13, name="apply_Model11"),
]
